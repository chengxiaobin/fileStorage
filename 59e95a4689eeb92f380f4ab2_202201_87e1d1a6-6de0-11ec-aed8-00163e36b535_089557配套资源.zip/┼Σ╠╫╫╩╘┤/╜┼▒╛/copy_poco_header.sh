mkdir include
cp -R Foundation/include .
cp -R Net/include .
cp -R Util/include .
cp -R XML/include .
cp -R Zip/include .
